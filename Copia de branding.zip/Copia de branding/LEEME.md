# Branding

Deja acá los archivos de marca. No hace falta que estén ordenados ni con
nombres perfectos: con que lleguen al subdirectorio correcto es suficiente.

```
branding/
  logo/          logotipo, isotipo, versiones en color y monocromas
  fotos/         fotos de la barra, los cócteles y los eventos
  tipografias/   fuentes licenciadas, si las tienes
  paleta/        colores de marca, si están definidos
  referencias/   sitios o imágenes que te gusten como referencia de estilo
```

Si algo no calza en ninguna carpeta, déjalo en `branding/` y lo ubico yo.

## Qué necesito de cada cosa

### `logo/`

**Ya está aplicado.** El sello del sitio se generó desde `Mesa de trabajo 38.svg`
y el favicon desde el 44. Si el logo cambia, hay que regenerar
`src/components/Sello.tsx` y `src/app/icon.svg` (el comando está en el README).

Lo ideal es **SVG**, porque escala sin pixelarse y puedo recolorearlo. Si no
tienes SVG, sirve PNG con fondo transparente a 2× el tamaño de uso (por ejemplo,
400 px de ancho para mostrarlo a 200 px).

Si existe, mándame también:

- versión horizontal (para la cabecera) y vertical o isotipo solo (para el pie y
  para el favicon);
- versión monocroma en negro y en blanco, para cuando el logo caiga sobre fondo
  oscuro o sobre foto.

Con un solo archivo también avanzo, pero después no puedo inventar las versiones
que falten sin deformar lo que hay.

### `fotos/`

**Ya están aplicadas**: diez fotos en `public/fotos/`, en dos medidas cada una.

Todas son verticales (3:4), lo que condiciona el diseño: no se estiran a sangre
en franjas anchas porque el sujeto se pierde. Si llegan fotos horizontales, se
pueden usar en bandas a sangre, que es un recurso que hoy está desaprovechado.

Para sumar más, necesito saber qué puedo mostrar.

Para cada foto me sirve saber, aunque sea en un `.txt` suelto:

- qué se ve y de qué evento es;
- si tengo permiso para publicarla (sobre todo si aparecen invitados
  identificables o menores de edad);
- quién la tomó, si hay que acreditar.

Formatos: JPG, PNG o HEIC. Mándalas **sin comprimir por WhatsApp** si puedes,
porque ese canal las destruye.

Lo que más falta, en orden de impacto:

1. **La barra montada y funcionando**, con alguien sirviendo. Es la foto del hero.
2. **Tres o cuatro cócteles de la carta**, bien iluminados y en su vaso real.
3. **Un plano del montaje completo** (barra + contexto del evento).

Con una foto buena de la barra cambiaría el hero entero: el actual está pensado
para texto y no luce bien con imagen encima.

### `tipografias/`

Ya están aplicadas: **Montserrat** (titulares y texto) y **Mairo** (acentos
manuscritos), la última desde `tipografias/mairo.woff`.

Mairo es una tipografía de trazo hecho a mano: se usa solo en frases cortas
—la clase `.mano`— porque en párrafos o titulares largos pierde legibilidad. Si
se suma una tercera tipografía, hacen falta los archivos `.woff2` **y la
licencia**: publicar una fuente sin licencia web es un problema legal, no un
detalle técnico.

### `paleta/`

Si los colores ya están definidos, mándalos como quieras: un `.txt` con los
hexadecimales, un PDF de marca o incluso una foto de la que saco los tonos.

Ya están aplicados, tomados de `paleta/Mesa de trabajo 46.png`:

| Uso | Hex |
| --- | --- |
| Rojo (acento principal) | `#c60015` |
| Rojo hondo (secciones oscuras) | `#8a0019` |
| Rojo profundo | `#6d0002` |
| Rojo medio | `#d13344` |
| Rosa (acento sobre rojo) | `#dd6673` |
| Crema (bandas teñidas) | `#ffe3e4` |
| Tinta (texto) | `#131311` |
| Carbón | `#262622` |
| Gris | `#706f6a` |
| Gris medio | `#94938f` |

### `referencias/`

Si viste un sitio, una marca o un menú que te gusta cómo se ve, déjalo acá con
una línea diciendo qué te gusta de eso. Es la forma más rápida de acertarle al
estilo sin dar diez vueltas.

## Cómo se aplica el branding al sitio

Ya está aplicado. El sistema de diseño está construido sobre variables CSS: un
cambio de paleta se edita en un bloque de `src/app/globals.css` y se propaga
solo a todo el sitio, cabecera, tarjetas, tablas y cotizador interno incluidos.

Lo que **no** se resuelve con variables y hay que regenerar aparte: el sello
(`src/components/Sello.tsx`), el favicon (`src/app/icon.svg`), la imagen para
compartir (`public/og.jpg`) y los iconos (`src/data/iconos.ts`). Los comandos
están en el README.

Lo que **no** se resuelve con variables y hay que tocar aparte: el favicon, la
imagen de vista previa al compartir el link (Open Graph) y el logotipo, porque
hoy el nombre se muestra como texto, no como imagen.

## Si todavía no hay branding

También es una respuesta válida. En ese caso el orden que recomiendo es:

1. **Nombre definitivo.** Sin eso no hay logo, ni dominio, ni redes. Es lo que
   bloquea todo lo demás y hoy en el sitio dice `RUTABAR`, que es un nombre de
   trabajo.
2. **Dos o tres fotos reales.** Rinden más que un logo para vender una barra.
3. **Paleta y tipografía.** Se resuelven después, y mientras tanto lo que hay
   funciona.
